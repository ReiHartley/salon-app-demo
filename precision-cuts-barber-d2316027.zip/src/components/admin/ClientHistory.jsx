import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Booking } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, User as UserIcon, Calendar, DollarSign } from "lucide-react";

export default function ClientHistory() {
  const [clients, setClients] = useState([]);
  const [filteredClients, setFilteredClients] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadClients();
  }, []);

  useEffect(() => {
    filterClients();
  }, [clients, searchTerm]);

  const loadClients = async () => {
    try {
      const users = await User.list();
      const bookings = await Booking.list();
      
      // Process client data with booking history
      const clientData = users
        .filter(user => user.role === 'user')
        .map(client => {
          const clientBookings = bookings.filter(b => b.client_email === client.email);
          const completedBookings = clientBookings.filter(b => b.status === 'completed');
          
          return {
            ...client,
            totalBookings: clientBookings.length,
            completedBookings: completedBookings.length,
            lastVisit: clientBookings.length > 0 
              ? Math.max(...clientBookings.map(b => new Date(b.appointment_date).getTime()))
              : null,
            recentBookings: clientBookings.slice(0, 5)
          };
        });
      
      setClients(clientData);
    } catch (error) {
      console.error("Error loading clients:", error);
    } finally {
      setLoading(false);
    }
  };

  const filterClients = () => {
    if (!searchTerm) {
      setFilteredClients(clients);
    } else {
      setFilteredClients(
        clients.filter(client => 
          client.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          client.email.toLowerCase().includes(searchTerm.toLowerCase())
        )
      );
    }
  };

  if (loading) {
    return (
      <div className="text-center py-8">
        <div className="animate-spin w-8 h-8 rounded-full border-4 border-charcoal border-t-gold mx-auto mb-4"></div>
        <p className="text-gray-600">Loading client history...</p>
      </div>
    );
  }

  return (
    <Card className="border-0 shadow-lg">
      <CardHeader>
        <CardTitle className="text-2xl font-bold text-charcoal">
          Client History & Preferences
        </CardTitle>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            placeholder="Search clients..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9"
          />
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {filteredClients.length === 0 ? (
            <p className="text-center text-gray-500 py-8">No clients found</p>
          ) : (
            filteredClients.map((client) => (
              <div key={client.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-charcoal rounded-full flex items-center justify-center">
                      <UserIcon className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg text-charcoal">{client.full_name}</h3>
                      <p className="text-sm text-gray-600">{client.email}</p>
                      {client.phone && <p className="text-sm text-gray-600">{client.phone}</p>}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Badge className="bg-blue-100 text-blue-800">
                      {client.totalBookings} bookings
                    </Badge>
                    <Badge className="bg-green-100 text-green-800">
                      {client.completedBookings} completed
                    </Badge>
                  </div>
                </div>
                
                <div className="grid md:grid-cols-3 gap-4 mb-4">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Calendar className="w-4 h-4" />
                    Last visit: {client.lastVisit 
                      ? new Date(client.lastVisit).toLocaleDateString()
                      : 'Never'
                    }
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <DollarSign className="w-4 h-4" />
                    Total spent: ${client.total_spent || 0}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <UserIcon className="w-4 h-4" />
                    Visits: {client.total_visits || 0}
                  </div>
                </div>
                
                {client.preferences && (
                  <div className="mb-4 p-3 bg-gray-50 rounded">
                    <h4 className="font-medium text-sm text-gray-700 mb-2">Preferences:</h4>
                    {client.preferences.preferred_barber && (
                      <p className="text-sm">Preferred Barber: {client.preferences.preferred_barber}</p>
                    )}
                    {client.preferences.preferred_services && (
                      <p className="text-sm">Preferred Services: {client.preferences.preferred_services.join(", ")}</p>
                    )}
                    {client.preferences.notes && (
                      <p className="text-sm">Notes: {client.preferences.notes}</p>
                    )}
                  </div>
                )}
                
                {client.recentBookings.length > 0 && (
                  <div>
                    <h4 className="font-medium text-sm text-gray-700 mb-2">Recent Bookings:</h4>
                    <div className="space-y-2">
                      {client.recentBookings.map((booking, index) => (
                        <div key={index} className="flex justify-between items-center text-sm bg-white p-2 rounded border">
                          <span>{new Date(booking.appointment_date).toLocaleDateString()} - {booking.appointment_time}</span>
                          <div className="flex gap-2">
                            <Badge variant="outline" className="text-xs">
                              {booking.service_names.join(", ")}
                            </Badge>
                            <Badge className={
                              booking.status === 'completed' ? 'bg-green-100 text-green-800' :
                              booking.status === 'confirmed' ? 'bg-blue-100 text-blue-800' :
                              'bg-yellow-100 text-yellow-800'
                            }>
                              {booking.status}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}