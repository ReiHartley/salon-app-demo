
import React, { useState, useEffect } from "react";
import { Booking } from "@/api/entities";
import { User } from "@/api/entities";
import { Service } from "@/api/entities";
import { Revenue } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, User as UserIcon, Phone, Mail } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function AppointmentManagement() {
  const [bookings, setBookings] = useState([]);
  const [services, setServices] = useState([]);
  const [filteredBookings, setFilteredBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState("all");

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    filterBookings();
  }, [bookings, statusFilter]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [bookingData, serviceData] = await Promise.all([
        Booking.list("-created_date"),
        Service.list(),
      ]);
      setBookings(bookingData);
      setServices(serviceData);
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setLoading(false);
    }
  };

  const filterBookings = () => {
    if (statusFilter === "all") {
      setFilteredBookings(bookings);
    } else {
      setFilteredBookings(bookings.filter(booking => booking.status === statusFilter));
    }
  };

  const updateBookingStatus = async (bookingId, newStatus) => {
    try {
      if (newStatus === 'completed') {
        const booking = bookings.find(b => b.id === bookingId);
        if (!booking) {
            console.error("Booking not found for revenue creation:", bookingId);
            return; 
        }

        const totalAmount = booking.service_names.reduce((sum, serviceName) => {
          const service = services.find(s => s.name === serviceName);
          return sum + (service ? service.price : 0);
        }, 0);

        if (totalAmount > 0) {
            await Revenue.create({
              date: booking.appointment_date,
              booking_id: booking.id,
              service_names: booking.service_names,
              amount: totalAmount,
              payment_method: 'card', // Default payment method
              stylist_name: booking.barber_preference || 'Not Specified',
              client_email: booking.client_email,
            });
        }
      }

      await Booking.update(bookingId, { status: newStatus });
      loadData();
    } catch (error) {
      console.error("Error updating booking status and creating revenue record:", error);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "pending": return "bg-yellow-100 text-yellow-800";
      case "confirmed": return "bg-blue-100 text-blue-800";
      case "completed": return "bg-green-100 text-green-800";
      case "cancelled": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  if (loading) {
    return (
      <div className="text-center py-8">
        <div className="animate-spin w-8 h-8 rounded-full border-4 border-charcoal border-t-gold mx-auto mb-4"></div>
        <p className="text-gray-600">Loading appointments...</p>
      </div>
    );
  }

  return (
    <Card className="border-0 shadow-lg">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-2xl font-bold text-charcoal">
            Appointment Management
          </CardTitle>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="confirmed">Confirmed</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="cancelled">Cancelled</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {filteredBookings.length === 0 ? (
            <p className="text-center text-gray-500 py-8">No appointments found</p>
          ) : (
            filteredBookings.map((booking) => (
              <div key={booking.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="font-semibold text-lg text-charcoal">{booking.client_name}</h3>
                    <div className="flex items-center gap-4 text-sm text-gray-600 mt-1">
                      <div className="flex items-center gap-1">
                        <Mail className="w-4 h-4" />
                        {booking.client_email}
                      </div>
                      <div className="flex items-center gap-1">
                        <Phone className="w-4 h-4" />
                        {booking.client_phone}
                      </div>
                    </div>
                  </div>
                  <Badge className={getStatusColor(booking.status)}>
                    {booking.status}
                  </Badge>
                </div>
                
                <div className="grid md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
                      <Calendar className="w-4 h-4" />
                      {new Date(booking.appointment_date).toLocaleDateString()}
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
                      <Clock className="w-4 h-4" />
                      {booking.appointment_time}
                    </div>
                    {booking.barber_preference && (
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <UserIcon className="w-4 h-4" />
                        {booking.barber_preference}
                      </div>
                    )}
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-700 mb-1">Services:</p>
                    <div className="flex flex-wrap gap-1">
                      {booking.service_names.map((service, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {service}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
                
                {booking.notes && (
                  <div className="mb-4 p-2 bg-gray-50 rounded text-sm">
                    <strong>Notes:</strong> {booking.notes}
                  </div>
                )}
                
                <div className="flex gap-2">
                  {booking.status === "pending" && (
                    <>
                      <Button
                        size="sm"
                        onClick={() => updateBookingStatus(booking.id, "confirmed")}
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        Confirm
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => updateBookingStatus(booking.id, "cancelled")}
                        className="border-red-300 text-red-600 hover:bg-red-50"
                      >
                        Cancel
                      </Button>
                    </>
                  )}
                  {booking.status === "confirmed" && (
                    <Button
                      size="sm"
                      onClick={() => updateBookingStatus(booking.id, "completed")}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      Mark Complete
                    </Button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
