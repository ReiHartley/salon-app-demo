import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, Users, Calendar, DollarSign } from "lucide-react";

export default function DashboardStats({ stats }) {
  const statCards = [
    {
      title: "Today's Revenue",
      value: `$${stats.todayRevenue || 0}`,
      change: "+12%",
      icon: DollarSign,
      color: "text-green-600"
    },
    {
      title: "Appointments Today",
      value: stats.todayAppointments || 0,
      change: "+5%",
      icon: Calendar,
      color: "text-blue-600"
    },
    {
      title: "Active Clients",
      value: stats.activeClients || 0,
      change: "+8%",
      icon: Users,
      color: "text-purple-600"
    },
    {
      title: "Monthly Growth",
      value: "15.2%",
      change: "+2.1%",
      icon: TrendingUp,
      color: "text-gold"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {statCards.map((stat, index) => (
        <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              {stat.title}
            </CardTitle>
            <stat.icon className={`h-5 w-5 ${stat.color}`} />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-charcoal">{stat.value}</div>
            <p className="text-xs text-gray-500 mt-2">
              <span className="text-green-500">{stat.change}</span> from last month
            </p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}