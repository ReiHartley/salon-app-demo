import React, { useState, useEffect } from "react";
import { Inventory } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Package, AlertTriangle, Plus, Edit2, Trash2, DollarSign } from "lucide-react";

export default function InventoryManagement() {
  const [inventory, setInventory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingItem, setEditingItem] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    product_name: "",
    category: "",
    current_stock: 0,
    minimum_stock: 0,
    cost_per_unit: 0,
    retail_price: 0,
    supplier: "",
    last_restocked: ""
  });

  const categories = ["hair_care", "styling", "tools", "cleaning", "retail"];

  useEffect(() => {
    loadInventory();
  }, []);

  const loadInventory = async () => {
    try {
      const data = await Inventory.list();
      setInventory(data);
    } catch (error) {
      console.error("Error loading inventory:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingItem) {
        await Inventory.update(editingItem.id, formData);
      } else {
        await Inventory.create(formData);
      }
      setShowForm(false);
      setEditingItem(null);
      setFormData({
        product_name: "",
        category: "",
        current_stock: 0,
        minimum_stock: 0,
        cost_per_unit: 0,
        retail_price: 0,
        supplier: "",
        last_restocked: ""
      });
      loadInventory();
    } catch (error) {
      console.error("Error saving inventory item:", error);
    }
  };

  const handleEdit = (item) => {
    setEditingItem(item);
    setFormData(item);
    setShowForm(true);
  };

  const handleDelete = async (itemId) => {
    if (confirm("Are you sure you want to delete this item?")) {
      try {
        await Inventory.delete(itemId);
        loadInventory();
      } catch (error) {
        console.error("Error deleting item:", error);
      }
    }
  };

  const getStockStatus = (item) => {
    if (item.current_stock <= item.minimum_stock) {
      return { status: "low", color: "bg-red-100 text-red-800" };
    } else if (item.current_stock <= item.minimum_stock * 1.5) {
      return { status: "medium", color: "bg-yellow-100 text-yellow-800" };
    } else {
      return { status: "good", color: "bg-green-100 text-green-800" };
    }
  };

  const getCategoryLabel = (category) => {
    return category.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase());
  };

  const lowStockItems = inventory.filter(item => item.current_stock <= item.minimum_stock);
  const totalValue = inventory.reduce((sum, item) => sum + (item.current_stock * item.cost_per_unit), 0);

  if (loading) {
    return (
      <div className="text-center py-8">
        <div className="animate-spin w-8 h-8 rounded-full border-4 border-charcoal border-t-gold mx-auto mb-4"></div>
        <p className="text-gray-600">Loading inventory...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Inventory Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Items</p>
                <p className="text-2xl font-bold text-charcoal">{inventory.length}</p>
              </div>
              <Package className="h-8 w-8 text-gold" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Low Stock Items</p>
                <p className="text-2xl font-bold text-red-600">{lowStockItems.length}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Value</p>
                <p className="text-2xl font-bold text-charcoal">${totalValue.toFixed(2)}</p>
              </div>
              <DollarSign className="h-8 w-8 text-gold" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Inventory Management */}
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-2xl font-bold text-charcoal">
              Inventory Management
            </CardTitle>
            <Dialog open={showForm} onOpenChange={setShowForm}>
              <DialogTrigger asChild>
                <Button className="bg-charcoal hover:bg-gold text-white hover:text-charcoal">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Product
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>
                    {editingItem ? 'Edit Product' : 'Add New Product'}
                  </DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="product_name">Product Name</Label>
                    <Input
                      id="product_name"
                      value={formData.product_name}
                      onChange={(e) => setFormData({...formData, product_name: e.target.value})}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="category">Category</Label>
                    <Select
                      value={formData.category}
                      onValueChange={(value) => setFormData({...formData, category: value})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((category) => (
                          <SelectItem key={category} value={category}>
                            {getCategoryLabel(category)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="current_stock">Current Stock</Label>
                      <Input
                        id="current_stock"
                        type="number"
                        value={formData.current_stock}
                        onChange={(e) => setFormData({...formData, current_stock: parseInt(e.target.value)})}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="minimum_stock">Minimum Stock</Label>
                      <Input
                        id="minimum_stock"
                        type="number"
                        value={formData.minimum_stock}
                        onChange={(e) => setFormData({...formData, minimum_stock: parseInt(e.target.value)})}
                        required
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="cost_per_unit">Cost per Unit</Label>
                      <Input
                        id="cost_per_unit"
                        type="number"
                        step="0.01"
                        value={formData.cost_per_unit}
                        onChange={(e) => setFormData({...formData, cost_per_unit: parseFloat(e.target.value)})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="retail_price">Retail Price</Label>
                      <Input
                        id="retail_price"
                        type="number"
                        step="0.01"
                        value={formData.retail_price}
                        onChange={(e) => setFormData({...formData, retail_price: parseFloat(e.target.value)})}
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="supplier">Supplier</Label>
                    <Input
                      id="supplier"
                      value={formData.supplier}
                      onChange={(e) => setFormData({...formData, supplier: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="last_restocked">Last Restocked</Label>
                    <Input
                      id="last_restocked"
                      type="date"
                      value={formData.last_restocked}
                      onChange={(e) => setFormData({...formData, last_restocked: e.target.value})}
                    />
                  </div>
                  <div className="flex gap-4">
                    <Button type="submit" className="bg-charcoal hover:bg-gold text-white hover:text-charcoal">
                      {editingItem ? 'Update' : 'Add'} Product
                    </Button>
                    <Button type="button" variant="outline" onClick={() => setShowForm(false)}>
                      Cancel
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {inventory.length === 0 ? (
              <p className="text-center text-gray-500 py-8">No inventory items found</p>
            ) : (
              inventory.map((item) => {
                const stockStatus = getStockStatus(item);
                return (
                  <div key={item.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="font-semibold text-lg">{item.product_name}</h3>
                          <Badge variant="outline">{getCategoryLabel(item.category)}</Badge>
                          <Badge className={stockStatus.color}>
                            {stockStatus.status === 'low' && <AlertTriangle className="w-3 h-3 mr-1" />}
                            {item.current_stock} units
                          </Badge>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-gray-600">
                          <div>
                            <span className="font-medium">Min Stock:</span> {item.minimum_stock}
                          </div>
                          <div>
                            <span className="font-medium">Cost:</span> ${item.cost_per_unit}
                          </div>
                          <div>
                            <span className="font-medium">Retail:</span> ${item.retail_price}
                          </div>
                          <div>
                            <span className="font-medium">Value:</span> ${(item.current_stock * item.cost_per_unit).toFixed(2)}
                          </div>
                        </div>
                        {item.supplier && (
                          <p className="text-sm text-gray-600 mt-2">Supplier: {item.supplier}</p>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" onClick={() => handleEdit(item)}>
                          <Edit2 className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => handleDelete(item.id)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}