import { base44 } from './base44Client';


export const Service = base44.entities.Service;

export const Booking = base44.entities.Booking;

export const Testimonial = base44.entities.Testimonial;

export const ContactMessage = base44.entities.ContactMessage;

export const StylistSchedule = base44.entities.StylistSchedule;

export const Revenue = base44.entities.Revenue;

export const Inventory = base44.entities.Inventory;



// auth sdk:
export const User = base44.auth;