
import React, { useState, useEffect } from "react";
import { Service } from "@/api/entities";
import { Booking } from "@/api/entities";
import { Calendar, Clock, User, Phone, Mail, MessageSquare, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function BookingPage() {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [formData, setFormData] = useState({
    client_name: "",
    client_email: "",
    client_phone: "",
    service_names: [],
    appointment_date: "",
    appointment_time: "",
    barber_preference: "",
    notes: ""
  });

  const timeSlots = [
    "9:00 AM", "9:30 AM", "10:00 AM", "10:30 AM", "11:00 AM", "11:30 AM",
    "12:00 PM", "12:30 PM", "1:00 PM", "1:30 PM", "2:00 PM", "2:30 PM",
    "3:00 PM", "3:30 PM", "4:00 PM", "4:30 PM", "5:00 PM", "5:30 PM", "6:00 PM"
  ];

  const barbers = ["Marcus Rodriguez", "James Thompson", "Antonio Silva"];

  useEffect(() => {
    loadServices();
  }, []);

  const loadServices = async () => {
    try {
      const data = await Service.list();
      setServices(data);
    } catch (error) {
      console.error("Error loading services:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleServiceToggle = (serviceName, checked) => {
    setFormData(prev => ({
      ...prev,
      service_names: checked 
        ? [...prev.service_names, serviceName]
        : prev.service_names.filter(name => name !== serviceName)
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);

    try {
      await Booking.create(formData);
      setSuccess(true);
      setFormData({
        client_name: "",
        client_email: "",
        client_phone: "",
        service_names: [],
        appointment_date: "",
        appointment_time: "",
        barber_preference: "",
        notes: ""
      });
    } catch (error) {
      console.error("Error creating booking:", error);
    } finally {
      setSubmitting(false);
    }
  };

  const getTotalPrice = () => {
    return formData.service_names.reduce((total, serviceName) => {
      const service = services.find(s => s.name === serviceName);
      return total + (service?.price || 0);
    }, 0);
  };

  const getTotalDuration = () => {
    return formData.service_names.reduce((total, serviceName) => {
      const service = services.find(s => s.name === serviceName);
      return total + (service?.duration || 0);
    }, 0);
  };

  if (success) {
    return (
      <div className="bg-white flex items-center justify-center py-40">
        <div className="max-w-md mx-auto text-center px-6">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-10 h-10 text-green-600" />
          </div>
          <h1 className="text-3xl font-bold text-charcoal mb-4">Booking Confirmed!</h1>
          <p className="text-gray-600 mb-8 leading-relaxed">
            Thank you for choosing Precision Cuts. We've received your appointment request 
            and will contact you shortly to confirm your booking.
          </p>
          <Button 
            onClick={() => setSuccess(false)}
            className="bg-charcoal hover:bg-gold text-white hover:text-charcoal"
          >
            Book Another Appointment
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50">
      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-br from-gray-900 to-gray-800 text-white">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            Book Your Appointment
          </h1>
          <p className="text-xl text-white font-semibold leading-relaxed">
            Schedule your visit to Precision Cuts and experience the difference of professional grooming.
          </p>
        </div>
      </section>

      {/* Booking Form */}
      <section className="py-12">
        <div className="max-w-4xl mx-auto px-6">
          <form onSubmit={handleSubmit} className="space-y-8">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Services Selection */}
              <div className="lg:col-span-2">
                <Card className="border-0 shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-charcoal">
                      <Calendar className="w-5 h-5" />
                      Select Services
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {loading ? (
                      <div className="text-center py-8">
                        <div className="animate-spin w-8 h-8 rounded-full border-4 border-charcoal border-t-gold mx-auto mb-4"></div>
                        <p className="text-gray-600">Loading services...</p>
                      </div>
                    ) : services.length === 0 ? (
                      <Alert>
                        <AlertDescription>
                          No services available. Please contact us to book your appointment.
                        </AlertDescription>
                      </Alert>
                    ) : (
                      <div className="grid md:grid-cols-2 gap-4">
                        {services.map((service) => (
                          <div 
                            key={service.id}
                            className="flex items-start space-x-3 p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                          >
                            <Checkbox
                              id={service.id}
                              checked={formData.service_names.includes(service.name)}
                              onCheckedChange={(checked) => handleServiceToggle(service.name, checked)}
                              className="mt-1"
                            />
                            <div className="flex-1">
                              <label 
                                htmlFor={service.id}
                                className="font-medium text-charcoal cursor-pointer"
                              >
                                {service.name}
                              </label>
                              <p className="text-sm text-gray-600 mt-1">{service.description}</p>
                              <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
                                <span className="font-medium">${service.price}</span>
                                <span className="flex items-center gap-1">
                                  <Clock className="w-3 h-3" />
                                  {service.duration} min
                                </span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Personal Information */}
                <Card className="border-0 shadow-lg mt-8">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-charcoal">
                      <User className="w-5 h-5" />
                      Your Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <Label htmlFor="client_name">Full Name *</Label>
                        <Input
                          id="client_name"
                          value={formData.client_name}
                          onChange={(e) => setFormData({...formData, client_name: e.target.value})}
                          placeholder="John Doe"
                          required
                          className="mt-2"
                        />
                      </div>
                      <div>
                        <Label htmlFor="client_phone">Phone Number *</Label>
                        <Input
                          id="client_phone"
                          type="tel"
                          value={formData.client_phone}
                          onChange={(e) => setFormData({...formData, client_phone: e.target.value})}
                          placeholder="(555) 123-4567"
                          required
                          className="mt-2"
                        />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="client_email">Email Address *</Label>
                      <Input
                        id="client_email"
                        type="email"
                        value={formData.client_email}
                        onChange={(e) => setFormData({...formData, client_email: e.target.value})}
                        placeholder="john@example.com"
                        required
                        className="mt-2"
                      />
                    </div>
                  </CardContent>
                </Card>

                {/* Appointment Details */}
                <Card className="border-0 shadow-lg mt-8">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-charcoal">
                      <Clock className="w-5 h-5" />
                      Appointment Details
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <Label htmlFor="appointment_date">Preferred Date *</Label>
                        <Input
                          id="appointment_date"
                          type="date"
                          value={formData.appointment_date}
                          onChange={(e) => setFormData({...formData, appointment_date: e.target.value})}
                          min={new Date().toISOString().split('T')[0]}
                          required
                          className="mt-2"
                        />
                      </div>
                      <div>
                        <Label htmlFor="appointment_time">Preferred Time *</Label>
                        <Select 
                          value={formData.appointment_time} 
                          onValueChange={(value) => setFormData({...formData, appointment_time: value})}
                        >
                          <SelectTrigger className="mt-2">
                            <SelectValue placeholder="Select time" />
                          </SelectTrigger>
                          <SelectContent>
                            {timeSlots.map((time) => (
                              <SelectItem key={time} value={time}>
                                {time}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="barber_preference">Barber Preference</Label>
                      <Select 
                        value={formData.barber_preference} 
                        onValueChange={(value) => setFormData({...formData, barber_preference: value})}
                      >
                        <SelectTrigger className="mt-2">
                          <SelectValue placeholder="Any barber (or select preference)" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value={null}>Any barber</SelectItem>
                          {barbers.map((barber) => (
                            <SelectItem key={barber} value={barber}>
                              {barber}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="notes">Additional Notes</Label>
                      <Textarea
                        id="notes"
                        value={formData.notes}
                        onChange={(e) => setFormData({...formData, notes: e.target.value})}
                        placeholder="Any special requests or notes for your barber..."
                        className="mt-2"
                        rows={3}
                      />
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Booking Summary */}
              <div>
                <Card className="border-0 shadow-lg sticky top-6">
                  <CardHeader>
                    <CardTitle className="text-charcoal">Booking Summary</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {formData.service_names.length > 0 ? (
                      <>
                        <div>
                          <h4 className="font-medium mb-3 text-charcoal">Selected Services:</h4>
                          <div className="space-y-2">
                            {formData.service_names.map((serviceName) => {
                              const service = services.find(s => s.name === serviceName);
                              return (
                                <div key={serviceName} className="flex justify-between text-sm text-gray-700">
                                  <span>{serviceName}</span>
                                  <span>${service?.price || 0}</span>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                        
                        <div className="border-t pt-4">
                          <div className="flex justify-between font-medium mb-2 text-charcoal">
                            <span>Total Price:</span>
                            <span className="text-lg text-charcoal">${getTotalPrice()}</span>
                          </div>
                          <div className="flex justify-between text-sm text-gray-600">
                            <span>Estimated Duration:</span>
                            <span>{getTotalDuration()} minutes</span>
                          </div>
                        </div>

                        {formData.appointment_date && formData.appointment_time && (
                          <div className="border-t pt-4">
                            <h4 className="font-medium mb-2 text-charcoal">Appointment:</h4>
                            <p className="text-sm text-gray-600">
                              {new Date(formData.appointment_date).toLocaleDateString('en-US', {
                                weekday: 'long',
                                year: 'numeric',
                                month: 'long',
                                day: 'numeric'
                              })}
                            </p>
                            <p className="text-sm text-gray-600">{formData.appointment_time}</p>
                            {formData.barber_preference && (
                              <p className="text-sm text-gray-600">
                                with {formData.barber_preference}
                              </p>
                            )}
                          </div>
                        )}
                      </>
                    ) : (
                      <p className="text-gray-500 text-center py-4">
                        Select services to see pricing
                      </p>
                    )}

                    <Button
                      type="submit"
                      disabled={submitting || formData.service_names.length === 0}
                      className="w-full bg-gold hover:bg-yellow-500 text-charcoal font-bold py-3 text-lg"
                    >
                      {submitting ? (
                        <>
                          <div className="animate-spin w-4 h-4 rounded-full border-2 border-charcoal border-t-transparent mr-2" />
                          Booking...
                        </>
                      ) : (
                        'Confirm Booking'
                      )}
                    </Button>

                    <div className="text-center">
                      <p className="text-xs text-gray-500 mb-2">
                        By booking, you agree to our terms of service
                      </p>
                      <div className="flex items-center justify-center gap-4 text-sm text-gray-600">
                        <div className="flex items-center gap-1">
                          <Phone className="w-3 h-3" />
                          <span>(555) 123-CUTS</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Mail className="w-3 h-3" />
                          <span>info@precisioncuts.com</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </form>
        </div>
      </section>
    </div>
  );
}
