
import React, { useState, useEffect } from "react";
import { Service } from "@/api/entities";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Scissors, Clock, Star, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Services() {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadServices();
  }, []);

  const loadServices = async () => {
    try {
      const data = await Service.list();
      setServices(data);
    } catch (error) {
      console.error("Error loading services:", error);
    } finally {
      setLoading(false);
    }
  };

  const getServicesByCategory = (category) => {
    return services.filter(service => service.category === category);
  };

  const ServiceCard = ({ service }) => (
    <Card className="group hover:shadow-xl transition-all duration-300 border-0 bg-white shadow-md">
      <CardHeader className="pb-4">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <h3 className="text-xl font-bold text-charcoal group-hover:text-gold transition-colors">
                {service.name}
              </h3>
              {service.popular && (
                <Badge className="bg-gold text-charcoal font-medium">
                  <Star className="w-3 h-3 mr-1" />
                  Popular
                </Badge>
              )}
            </div>
            <p className="text-gray-600 leading-relaxed mb-4">
              {service.description}
            </p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="text-2xl font-bold text-charcoal">
              ${service.price}
            </div>
            <div className="flex items-center gap-1 text-gray-500">
              <Clock className="w-4 h-4" />
              <span className="text-sm">{service.duration} min</span>
            </div>
          </div>
          <Link to={createPageUrl("Booking")}>
            <Button className="bg-charcoal hover:bg-gold text-white hover:text-charcoal transition-all duration-300">
              Book Now
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );

  if (loading) {
    return (
      <div className="bg-white flex items-center justify-center py-40">
        <div className="text-center">
          <div className="animate-spin w-12 h-12 rounded-full border-4 border-charcoal border-t-gold mx-auto mb-4"></div>
          <p className="text-gray-600">Loading services...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="py-12 bg-gradient-to-br from-charcoal to-gray-800 text-white">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
            Our Services
          </h1>
          
          <div className="max-w-3xl mx-auto">
            <p className="text-xl text-white font-medium mb-8 leading-relaxed">
              From classic cuts to modern styles, beard trims to traditional shaves—
              discover our comprehensive range of premium grooming services designed to keep you looking sharp.
            </p>
            
            <p className="text-lg text-gold font-medium tracking-wider">
              Expert Barbers &nbsp;•&nbsp; Premium Products &nbsp;•&nbsp; On-Time Service
            </p>
          </div>

        </div>
      </section>

      {/* Services Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-6">
          <Tabs defaultValue="haircut" className="w-full">
            <TabsList className="grid w-full grid-cols-4 max-w-2xl mx-auto mb-12 bg-gray-100">
              <TabsTrigger value="haircut" className="data-[state=active]:bg-charcoal data-[state=active]:text-white">
                Haircuts
              </TabsTrigger>
              <TabsTrigger value="beard" className="data-[state=active]:bg-charcoal data-[state=active]:text-white">
                Beard Care
              </TabsTrigger>
              <TabsTrigger value="styling" className="data-[state=active]:bg-charcoal data-[state=active]:text-white">
                Styling
              </TabsTrigger>
              <TabsTrigger value="package" className="data-[state=active]:bg-charcoal data-[state=active]:text-white">
                Packages
              </TabsTrigger>
            </TabsList>

            <TabsContent value="haircut" className="space-y-8">
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold text-charcoal mb-4">Haircut Services</h2>
                <p className="text-gray-600 max-w-2xl mx-auto">
                  From classic cuts to modern fades, our master barbers deliver precision and style.
                </p>
              </div>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {getServicesByCategory("haircut").map((service) => (
                  <ServiceCard key={service.id} service={service} />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="beard" className="space-y-8">
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold text-charcoal mb-4">Beard & Mustache</h2>
                <p className="text-gray-600 max-w-2xl mx-auto">
                  Professional beard trimming, shaping, and traditional wet shaves.
                </p>
              </div>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {getServicesByCategory("beard").map((service) => (
                  <ServiceCard key={service.id} service={service} />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="styling" className="space-y-8">
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold text-charcoal mb-4">Hair Styling</h2>
                <p className="text-gray-600 max-w-2xl mx-auto">
                  Complete your look with professional styling and premium products.
                </p>
              </div>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {getServicesByCategory("styling").map((service) => (
                  <ServiceCard key={service.id} service={service} />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="package" className="space-y-8">
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold text-charcoal mb-4">Package Deals</h2>
                <p className="text-gray-600 max-w-2xl mx-auto">
                  Save with our comprehensive grooming packages combining multiple services.
                </p>
              </div>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {getServicesByCategory("package").map((service) => (
                  <ServiceCard key={service.id} service={service} />
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-4xl mx-auto text-center px-6">
          <h2 className="text-4xl md:text-5xl font-bold text-charcoal mb-6">
            Ready to Look Your Best?
          </h2>
          <p className="text-xl text-gray-600 mb-8 leading-relaxed">
            Book your appointment today and experience the precision and quality 
            that sets Precision Cuts apart from the rest.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to={createPageUrl("Booking")}>
              <Button className="bg-gold hover:bg-yellow-500 text-charcoal px-8 py-4 text-lg font-bold rounded-lg transform transition-all duration-300 hover:scale-105">
                Book Appointment
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <Link to={createPageUrl("Contact")}>
              <Button variant="outline" className="border-2 border-charcoal text-charcoal hover:bg-charcoal hover:text-white px-8 py-4 text-lg font-semibold rounded-lg">
                Call Us
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
