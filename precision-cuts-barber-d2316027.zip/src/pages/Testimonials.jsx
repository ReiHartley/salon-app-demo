
import React, { useState, useEffect } from "react";
import { Testimonial } from "@/api/entities";
import { Star, Quote, Users, Award, ThumbsUp } from "lucide-react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export default function Testimonials() {
  const [testimonials, setTestimonials] = useState([]);
  const [featuredTestimonials, setFeaturedTestimonials] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAll, setShowAll] = useState(false);

  useEffect(() => {
    loadTestimonials();
  }, []);

  const loadTestimonials = async () => {
    try {
      const data = await Testimonial.list("-created_date");
      setTestimonials(data);
      setFeaturedTestimonials(data.filter(t => t.featured));
    } catch (error) {
      console.error("Error loading testimonials:", error);
    } finally {
      setLoading(false);
    }
  };

  const StarRating = ({ rating }) => (
    <div className="flex items-center gap-1">
      {[...Array(5)].map((_, i) => (
        <Star 
          key={i} 
          className={`w-5 h-5 ${i < rating ? 'text-gold fill-current' : 'text-gray-300'}`} 
        />
      ))}
    </div>
  );

  const TestimonialCard = ({ testimonial, featured = false }) => (
    <Card className={`${featured ? 'border-gold border-2 bg-gradient-to-br from-gold/5 to-gold/10' : 'border-0 bg-white'} shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105`}>
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between mb-4">
          <StarRating rating={testimonial.rating} />
          {featured && (
            <Badge className="bg-gold text-charcoal font-semibold">
              <Award className="w-3 h-3 mr-1" />
              Featured
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="mb-6 relative">
          <Quote className="w-8 h-8 text-gold/30 absolute -top-2 -left-2" />
          <p className="text-gray-700 leading-relaxed italic pl-6">
            {testimonial.review}
          </p>
        </div>
        <div className="border-t pt-4">
          <p className="font-bold text-charcoal text-lg">{testimonial.client_name}</p>
          {testimonial.service_received && (
            <p className="text-gray-500 text-sm mt-1">{testimonial.service_received}</p>
          )}
        </div>
      </CardContent>
    </Card>
  );

  const averageRating = testimonials.length > 0 
    ? (testimonials.reduce((sum, t) => sum + t.rating, 0) / testimonials.length).toFixed(1)
    : 0;

  if (loading) {
    return (
      <div className="bg-white flex items-center justify-center py-40">
        <div className="text-center">
          <div className="animate-spin w-12 h-12 rounded-full border-4 border-charcoal border-t-gold mx-auto mb-4"></div>
          <p className="text-gray-600">Loading testimonials...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="py-12 bg-gradient-to-br from-charcoal to-gray-800 text-white">
        <div className="max-w-6xl mx-auto px-6 text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
            Client Testimonials
          </h1>
          <p className="text-xl text-white font-medium mb-8 max-w-3xl mx-auto leading-relaxed">
            Don't just take our word for it. Here's what our valued clients have to say 
            about their experience at Precision Cuts.
          </p>
          
          {/* Stats */}
          <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-8 max-w-2xl mx-auto">
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-gold mb-2">{testimonials.length}+</div>
              <div className="text-gray-300">Reviews</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-gold mb-2">{averageRating}</div>
              <div className="text-gray-300">Average Rating</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-gold mb-2">98%</div>
              <div className="text-gray-300">Satisfaction</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-gold mb-2">3</div>
              <div className="text-gray-300">Expert Barbers</div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Testimonials */}
      {featuredTestimonials.length > 0 && (
        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-bold text-charcoal mb-6">
                Featured Reviews
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                These standout reviews showcase the exceptional experiences our clients have at Precision Cuts.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredTestimonials.map((testimonial) => (
                <TestimonialCard key={testimonial.id} testimonial={testimonial} featured={true} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* All Testimonials */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-charcoal mb-6">
              What Our Clients Say
            </h2>
            <div className="w-20 h-1 bg-gold mx-auto mb-8"></div>
            <div className="flex items-center justify-center gap-2 mb-8">
              <StarRating rating={Math.round(averageRating)} />
              <span className="text-2xl font-bold text-charcoal ml-3">{averageRating}</span>
              <span className="text-gray-600">({testimonials.length} reviews)</span>
            </div>
          </div>

          {testimonials.length === 0 ? (
            <div className="text-center py-12">
              <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 text-lg">No testimonials available yet.</p>
            </div>
          ) : (
            <>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
                {(showAll ? testimonials : testimonials.slice(0, 6)).map((testimonial) => (
                  <TestimonialCard key={testimonial.id} testimonial={testimonial} />
                ))}
              </div>

              {testimonials.length > 6 && (
                <div className="text-center">
                  <Button
                    onClick={() => setShowAll(!showAll)}
                    variant="outline"
                    className="border-2 border-charcoal text-charcoal hover:bg-charcoal hover:text-white px-8 py-3 font-semibold"
                  >
                    {showAll ? 'Show Less' : `View All ${testimonials.length} Reviews`}
                  </Button>
                </div>
              )}
            </>
          )}
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-charcoal text-white">
        <div className="max-w-4xl mx-auto text-center px-6">
          <div className="flex items-center justify-center gap-3 mb-6">
            <ThumbsUp className="w-12 h-12 text-gold" />
            <h2 className="text-4xl md:text-5xl font-bold">
              Join Our Happy Clients
            </h2>
          </div>
          <p className="text-xl text-gray-300 mb-8 leading-relaxed">
            Experience the quality and service that our clients rave about. 
            Book your appointment today and see why Precision Cuts is the top choice in Downtown.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="/booking"
              className="bg-gold hover:bg-yellow-500 text-charcoal px-8 py-4 text-lg font-bold rounded-lg transform transition-all duration-300 hover:scale-105 inline-block"
            >
              Book Your Appointment
            </a>
            <a 
              href="/contact"
              className="border-2 border-white text-white hover:bg-white hover:text-charcoal px-8 py-4 text-lg font-semibold rounded-lg transition-all duration-300 inline-block"
            >
              Contact Us
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
